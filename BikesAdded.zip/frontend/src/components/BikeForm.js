import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

function BikeForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditMode = !!id;

  const [formData, setFormData] = useState({
    bikeId: '',
    bikeName: '',
    brand: '',
    model: '',
    year: '',
    price: '',
    color: '',
    engineCC: ''
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [fetchingBike, setFetchingBike] = useState(false);

  useEffect(() => {
    if (isEditMode) {
      fetchBikeData();
    }
  }, [id]);

  const fetchBikeData = async () => {
    setFetchingBike(true);
    try {
      const response = await axios.get(`/api/bikes/${id}`);
      setFormData(response.data.bike);
    } catch (error) {
      console.error('Error fetching bike:', error);
      alert('Failed to fetch bike data');
      navigate('/bikes');
    } finally {
      setFetchingBike(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    setErrors(prev => ({
      ...prev,
      [name]: ''
    }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.bikeId) newErrors.bikeId = 'Bike ID is required';
    if (!formData.bikeName) newErrors.bikeName = 'Bike name is required';
    if (!formData.brand) newErrors.brand = 'Brand is required';
    if (!formData.model) newErrors.model = 'Model is required';
    if (!formData.year) newErrors.year = 'Year is required';
    if (!formData.price) newErrors.price = 'Price is required';

    if (formData.year && (formData.year < 1900 || formData.year > new Date().getFullYear() + 1)) {
      newErrors.year = `Year must be between 1900 and ${new Date().getFullYear() + 1}`;
    }

    if (formData.price && formData.price < 0) {
      newErrors.price = 'Price must be positive';
    }

    if (formData.engineCC && formData.engineCC < 0) {
      newErrors.engineCC = 'Engine capacity must be positive';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      if (isEditMode) {
        await axios.put(`/api/bikes/${id}`, formData);
        alert('Bike updated successfully!');
      } else {
        await axios.post('/api/bikes', formData);
        alert('Bike added successfully!');
      }
      navigate('/bikes');
    } catch (error) {
      console.error('Error saving bike:', error);
      if (error.response?.data?.message) {
        alert(error.response.data.message);
      } else {
        alert('Failed to save bike. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    navigate('/bikes');
  };

  if (fetchingBike) {
    return <div className="loading">Loading bike data...</div>;
  }

  return (
    <div className="container">
      <div className="form-container">
        <h2>{isEditMode ? 'Edit Bike' : 'Add New Bike'}</h2>
        
        <form onSubmit={handleSubmit}>
          <div className="form-section">
            <h3>Basic Information</h3>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="bikeId">Bike ID *</label>
                <input
                  type="text"
                  id="bikeId"
                  name="bikeId"
                  value={formData.bikeId}
                  onChange={handleChange}
                  disabled={isEditMode}
                  className={errors.bikeId ? 'error' : ''}
                />
                {errors.bikeId && <span className="error-message">{errors.bikeId}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="bikeName">Bike Name *</label>
                <input
                  type="text"
                  id="bikeName"
                  name="bikeName"
                  value={formData.bikeName}
                  onChange={handleChange}
                  className={errors.bikeName ? 'error' : ''}
                />
                {errors.bikeName && <span className="error-message">{errors.bikeName}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="brand">Brand *</label>
                <input
                  type="text"
                  id="brand"
                  name="brand"
                  value={formData.brand}
                  onChange={handleChange}
                  className={errors.brand ? 'error' : ''}
                />
                {errors.brand && <span className="error-message">{errors.brand}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="model">Model *</label>
                <input
                  type="text"
                  id="model"
                  name="model"
                  value={formData.model}
                  onChange={handleChange}
                  className={errors.model ? 'error' : ''}
                />
                {errors.model && <span className="error-message">{errors.model}</span>}
              </div>
            </div>
          </div>

          <div className="form-section">
            <h3>Specifications</h3>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="year">Year *</label>
                <input
                  type="number"
                  id="year"
                  name="year"
                  value={formData.year}
                  onChange={handleChange}
                  className={errors.year ? 'error' : ''}
                />
                {errors.year && <span className="error-message">{errors.year}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="price">Price (₹) *</label>
                <input
                  type="number"
                  id="price"
                  name="price"
                  value={formData.price}
                  onChange={handleChange}
                  className={errors.price ? 'error' : ''}
                />
                {errors.price && <span className="error-message">{errors.price}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="color">Color</label>
                <input
                  type="text"
                  id="color"
                  name="color"
                  value={formData.color}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label htmlFor="engineCC">Engine Capacity (CC)</label>
                <input
                  type="number"
                  id="engineCC"
                  name="engineCC"
                  value={formData.engineCC}
                  onChange={handleChange}
                  className={errors.engineCC ? 'error' : ''}
                />
                {errors.engineCC && <span className="error-message">{errors.engineCC}</span>}
              </div>
            </div>
          </div>

          <div className="form-buttons">
            <button type="button" onClick={handleCancel} className="btn btn-secondary">
              Cancel
            </button>
            <button type="submit" disabled={loading} className="btn btn-primary">
              {loading ? 'Saving...' : (isEditMode ? 'Update Bike' : 'Add Bike')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default BikeForm;