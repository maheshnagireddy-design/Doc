import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

function BikeList() {
  const [bikes, setBikes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredBikes, setFilteredBikes] = useState([]);

  useEffect(() => {
    fetchBikes();
  }, []);

  useEffect(() => {
    const filtered = bikes.filter(bike =>
      bike.bikeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bike.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bike.bikeId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bike.model.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredBikes(filtered);
  }, [searchTerm, bikes]);

  const fetchBikes = async () => {
    try {
      const response = await axios.get('/api/bikes');
      setBikes(response.data.bikes);
      setFilteredBikes(response.data.bikes);
    } catch (error) {
      console.error('Error fetching bikes:', error);
      alert('Failed to fetch bikes');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id, bikeName) => {
    if (window.confirm(`Are you sure you want to delete ${bikeName}?`)) {
      try {
        await axios.delete(`/api/bikes/${id}`);
        setBikes(bikes.filter(bike => bike._id !== id));
        alert('Bike deleted successfully');
      } catch (error) {
        console.error('Error deleting bike:', error);
        alert('Failed to delete bike');
      }
    }
  };

  if (loading) {
    return <div className="loading">Loading bikes...</div>;
  }

  return (
    <div className="container">
      <div className="list-header">
        <h2>Bikes List</h2>
        <div className="list-actions">
          <input
            type="text"
            placeholder="Search bikes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
          <Link to="/bikes/new" className="btn btn-primary">
            Add New Bike
          </Link>
        </div>
      </div>

      {filteredBikes.length > 0 ? (
        <div className="table-container">
          <table className="students-table">
            <thead>
              <tr>
                <th>Bike ID</th>
                <th>Name</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Year</th>
                <th>Price</th>
                <th>Color</th>
                <th>Engine (CC)</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredBikes.map((bike) => (
                <tr key={bike._id}>
                  <td>{bike.bikeId}</td>
                  <td>{bike.bikeName}</td>
                  <td>{bike.brand}</td>
                  <td>{bike.model}</td>
                  <td>{bike.year}</td>
                  <td>₹{bike.price?.toLocaleString()}</td>
                  <td>{bike.color || 'N/A'}</td>
                  <td>{bike.engineCC || 'N/A'}</td>
                  <td className="actions">
                    <Link to={`/bikes/edit/${bike._id}`} className="btn-small btn-edit">
                      Edit
                    </Link>
                    <button
                      onClick={() => handleDelete(bike._id, bike.bikeName)}
                      className="btn-small btn-delete"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : searchTerm ? (
        <div className="no-data">
          <p>No bikes found matching "{searchTerm}"</p>
        </div>
      ) : (
        <div className="no-data">
          <p>No bikes found.</p>
          <Link to="/bikes/new" className="btn btn-primary">
            Add Your First Bike
          </Link>
        </div>
      )}
    </div>
  );
}

export default BikeList;