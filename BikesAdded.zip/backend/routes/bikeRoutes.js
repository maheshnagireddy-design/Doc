const express = require('express');
const router = express.Router();
const Bike = require('../models/Bike');
const { protect } = require('../middleware/auth');

// @route GET /api/bikes
// @desc Get all bikes for logged-in user
// @access Private
router.get('/', protect, async (req, res) => {
  try {
    const bikes = await Bike.find({ createdBy: req.user._id })
      .sort({ createdAt: -1 });
    
    res.json({
      success: true,
      count: bikes.length,
      bikes
    });
  } catch (error) {
    console.error('Get bikes error:', error);
    res.status(500).json({ message: error.message });
  }
});

// @route GET /api/bikes/:id
// @desc Get single bike by ID
// @access Private
router.get('/:id', protect, async (req, res) => {
  try {
    const bike = await Bike.findOne({
      _id: req.params.id,
      createdBy: req.user._id
    });

    if (!bike) {
      return res.status(404).json({ message: 'Bike not found' });
    }

    res.json({
      success: true,
      bike
    });
  } catch (error) {
    console.error('Get bike error:', error);
    res.status(500).json({ message: error.message });
  }
});

// @route POST /api/bikes
// @desc Create new bike
// @access Private
router.post('/', protect, async (req, res) => {
  try {
    const bikeData = {
      ...req.body,
      createdBy: req.user._id
    };

    const bike = await Bike.create(bikeData);

    res.status(201).json({
      success: true,
      bike
    });
  } catch (error) {
    console.error('Create bike error:', error);
    
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];
      return res.status(400).json({
        message: `A bike with this ${field} already exists`
      });
    }

    res.status(500).json({ message: error.message });
  }
});

// @route PUT /api/bikes/:id
// @desc Update bike
// @access Private
router.put('/:id', protect, async (req, res) => {
  try {
    const bike = await Bike.findOneAndUpdate(
      { _id: req.params.id, createdBy: req.user._id },
      req.body,
      { new: true, runValidators: true }
    );

    if (!bike) {
      return res.status(404).json({ message: 'Bike not found' });
    }

    res.json({
      success: true,
      bike
    });
  } catch (error) {
    console.error('Update bike error:', error);
    
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];
      return res.status(400).json({
        message: `A bike with this ${field} already exists`
      });
    }

    res.status(500).json({ message: error.message });
  }
});

// @route DELETE /api/bikes/:id
// @desc Delete bike
// @access Private
router.delete('/:id', protect, async (req, res) => {
  try {
    const bike = await Bike.findOneAndDelete({
      _id: req.params.id,
      createdBy: req.user._id
    });

    if (!bike) {
      return res.status(404).json({ message: 'Bike not found' });
    }

    res.json({
      success: true,
      message: 'Bike deleted successfully'
    });
  } catch (error) {
    console.error('Delete bike error:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;