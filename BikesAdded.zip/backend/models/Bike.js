
const mongoose = require('mongoose');

const bikeSchema = new mongoose.Schema({
  bikeId: {
    type: String,
    required: [true, 'Bike ID is required'],
    unique: true,
    trim: true
  },
  bikeName: {
    type: String,
    required: [true, 'Bike name is required'],
    trim: true
  },
  brand: {
    type: String,
    required: [true, 'Brand is required'],
    trim: true
  },
  model: {
    type: String,
    required: [true, 'Model is required'],
    trim: true
  },
  year: {
    type: Number,
    required: [true, 'Year is required'],
    min: [1900, 'Year must be after 1900'],
    max: [new Date().getFullYear() + 1, 'Year cannot be in the future']
  },
  price: {
    type: Number,
    required: [true, 'Price is required'],
    min: [0, 'Price must be positive']
  },
  color: {
    type: String,
    trim: true
  },
  engineCC: {
    type: Number,
    min: [0, 'Engine capacity must be positive']
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

bikeSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Bike', bikeSchema);